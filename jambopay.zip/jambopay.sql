-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2020 at 02:57 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jambopay`
--

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `s_id` int(11) NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `service_code` varchar(100) NOT NULL,
  `service_commission_percent` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`s_id`, `service_name`, `service_code`, `service_commission_percent`) VALUES
(1, 'Water', 'H20', '3.00'),
(2, 'Electricity', 'ELTR', '2.00'),
(3, 'Airtime', 'AIRTM', '5.00');

-- --------------------------------------------------------

--
-- Table structure for table `supporters`
--

CREATE TABLE `supporters` (
  `s_id` int(11) NOT NULL,
  `ambassador_id` varchar(100) NOT NULL,
  `supporter_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supporters`
--

INSERT INTO `supporters` (`s_id`, `ambassador_id`, `supporter_id`) VALUES
(2, 'shawnmbuvi@gmail.com', 'shawnmbuvi1@gmail.com'),
(3, 'seanandre30@gmail', 'supporterandre31@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `t_id` int(11) NOT NULL,
  `supporter_id` varchar(100) NOT NULL,
  `ambassador_id` varchar(100) NOT NULL,
  `service_code` varchar(100) NOT NULL,
  `transaction_cost` decimal(10,2) NOT NULL,
  `ambassador_commission` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`t_id`, `supporter_id`, `ambassador_id`, `service_code`, `transaction_cost`, `ambassador_commission`) VALUES
(3, 'supporterandre31@gmail.com', 'seanandre30@gmail', 'H20', '300.00', '9.00'),
(4, 'supporterandre31@gmail.com', 'seanandre30@gmail', 'H20', '350.00', '10.50');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `id_number` varchar(20) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `fname`, `lname`, `phone_no`, `id_number`, `user_type`, `email`, `password`) VALUES
(6, 'Shawn', 'Mbuvi', '0727088016', '29501445', 'ambassador', 'shawnmbuvi@gmail.com', 'CpaKXSxtQCGAs7IIOaj2pA=='),
(8, 'mbuvi', 'ngutu', '0722990089', '267190202', 'supporter', 'shawnmbuvi1@gmail.com', 'gdyb21LQTcIANtvYMT7QVQ=='),
(13, 'Shawn', 'Andre', '0731628560', '29501445', 'ambassador', 'seanandre30@gmail.com', 'gdyb21LQTcIANtvYMT7QVQ=='),
(16, 'Shawn_Supporter', 'Andre_Supporter', '0731628560', '29501448', 'supporter', 'supporterandre31@gmail.com', 'gdyb21LQTcIANtvYMT7QVQ==');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`s_id`),
  ADD UNIQUE KEY `service_code` (`service_code`);

--
-- Indexes for table `supporters`
--
ALTER TABLE `supporters`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `supporters`
--
ALTER TABLE `supporters`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `t_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
